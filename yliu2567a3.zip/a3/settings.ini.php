host = localhost
user = root
password = ""
dbname = yliu2567assign2db
