<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container" style="padding-left: 0px;">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-5" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-5">
            <p class="navbar-text"><a href="index.php" class="danger navbar-link">Doctor</a></p>
            <p class="navbar-text"><a href="patient.php" class="danger navbar-link">Patient</a></p>
            <p class="navbar-text"><a href="hospital.php" class="danger navbar-link">Hospital</a></p>
        </div>
    </div>
</nav>

